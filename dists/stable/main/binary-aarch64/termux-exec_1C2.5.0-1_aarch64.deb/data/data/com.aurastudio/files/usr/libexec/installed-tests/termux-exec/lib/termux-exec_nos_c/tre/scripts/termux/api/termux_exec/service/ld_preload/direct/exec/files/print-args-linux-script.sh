#!/data/data/com.aurastudio/files/usr/bin/sh

echo "$@"
