if [ ! -f /data/data/com.aurastudio/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.aurastudio/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.aurastudio/files/home/.termux
	cp /data/data/com.aurastudio/files/usr/share/examples/termux/termux.properties /data/data/com.aurastudio/files/home/.termux/
fi
