##
## This script is sourced by /data/data/com.aurastudio/files/usr/bin/login before executing shell.
##
