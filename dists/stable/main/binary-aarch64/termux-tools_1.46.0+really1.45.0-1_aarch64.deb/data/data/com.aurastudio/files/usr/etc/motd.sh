#!/data/data/com.aurastudio/files/usr/bin/bash

# Setup TERMUX_APP_PACKAGE_MANAGER
source "/data/data/com.aurastudio/files/usr/bin/termux-setup-package-manager" || exit 1

motd="
\e[1m\e[38;2;99;102;241mWelcome to AuraStudio!\e[0m
\e[2mAndroid Development Environment\e[0m

\e[2mGet started:\e[0m
  aurastudio setup    \e[2m# Configure environment\e[0m
  aurastudio status   \e[2m# Check installed tools\e[0m
  aurastudio doctor   \e[2m# Run diagnostics\e[0m

\e[2mQuick commands:\e[0m
  apt search <pkg>    \e[2m# Search packages\e[0m
  apt install <pkg>   \e[2m# Install package\e[0m
  java -version       \e[2m# Check Java\e[0m
  gradle --version    \e[2m# Check Gradle\e[0m

\e[2mDocs: \e[4mhttps://arata-labs.github.io/aurastudio\e[0m
"
echo -e "$motd"
